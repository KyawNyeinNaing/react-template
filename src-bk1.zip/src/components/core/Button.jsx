import styled from 'styled-components'
import { rgba } from 'polished'
import { Colors } from '../constant/'
import { fontSize, fontWeight, General } from '../constant'

const Button = styled.button`
  cursor: pointer;
  min-width: 150px;
  min-height: 40px;
  padding: 0 20px;
  display: inline-block;
  border: 2px solid transparent;
  border-radius: .4rem;
  text-align: center;
  color: ${Colors?.black};
  font-size: ${fontSize.md}px;
  transition: box-shadow .15s ease;
  outline: 0;
  &:hover {
    box-shadow: 0 2px 5px 0 ${rgba(Colors?.black, .1)}, 0 2px 10px 0 ${rgba(Colors?.black, .06)};
  }
  &.primary {
    border: ${General.border} ${Colors?.primary};
    background-color: ${Colors?.primary};

    &:hover {
      background-color: ${rgba(Colors?.primary, .7)};
      border-color: ${rgba(Colors?.primary, .7)};
    }
  }
  &.secondary {
    border: ${General.border} ${Colors?.light};
    background-color: ${Colors?.light};
    color: ${Colors?.primary};

    &:hover {
      background-color: ${Colors?.bgColor};
      border-color: ${Colors?.bgColor};
    }
  }
  &.with-icon {
    display: flex;
    align-items: center;
    justify-content: center;

    svg {
      font-size: 20px;
      margin-right: 10px;
      transition: color .15s ease-in-out;
    }

    &:hover {
      svg {
        color: ${Colors?.white};
      }
    }
  }
  &.outline-primary {
    color: ${Colors?.primary};
    border: 2px solid ${Colors?.primary};
    background-color: ${Colors?.white};

    &:hover {
      background-color: ${Colors?.primary};
      color: ${Colors?.white};
    }

    svg {
      color: ${Colors?.primary};
    }
  }
  &.outline-secondary {
    color: ${Colors?.black};
    border: 2px solid ${Colors?.primary};
    border-radius: 0;
    background-color: ${Colors?.white};

    &:hover {
      background-color: ${Colors?.primary};
      color: ${Colors?.white};
    }
  }
  &.product-btn {
    overflow: hidden;
    position: relative;
    height: 40px;

    &:hover {
      span {
        transform: translateY(-100px);
      }

      svg {
        transform: translateY(-31px);
      }
    }

    span {
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: transform .3s ease;
    }

    svg {
      font-size: 26px;
      transform: translateY(100px);
      transition: transform .3s ease;
      pointer-events: none;
    }
  }
  &.read-more {
    min-width: auto;
    padding: 0;
    border: 0;
    outline: 0;
    background: 0;
    box-shadow: none;
    color: ${Colors?.primary};
    text-transform: uppercase;
    font-weight: ${fontWeight.xl};

    &:hover {
      box-shadow: none;
    }

    svg {
      color: ${Colors?.primary};
      pointer-events: none;
    }
  }
  &.btn-link {
    color: ${Colors?.primary};
    background-color: transparent !important;
    border: none;
    span {
      border-bottom: 1px solid ${Colors?.primary};
    }
    &:hover {
      border: none;
      box-shadow: none;
    }
  }
  &.btn-disabled {
    opacity: .5;
    cursor: default;
    background-color: ${Colors?.primary};
    &:hover {
      background-color: ${Colors?.primary};
      border: none;
    }
    span {
      cursor: default !important;
    }
  }
`
export { Button }