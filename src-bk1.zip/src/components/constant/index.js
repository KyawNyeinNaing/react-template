export * from './Color'

export * from './Color1'

export * from './FontSize'

export * from './General'

export * from './Media'