import React from 'react'

const TableBody = ({ data }) => {

  return (
    <tbody>
      {data}
    </tbody>
  )
}

export default TableBody
