import React from 'react'
import { NavLink } from 'react-router-dom'
import Components from '../../components'
import { NavContainer, MenuDropdown } from './style/HeaderStyle'
import { MdKeyboardArrowDown } from 'react-icons/md'
import { closeDrawer } from '../../utils'

export default function PrimaryNav() {

  return (
    <NavContainer className="primaryNav" primary>
      <Components.Container className="nav-container">
        <ul className="nav-item-wrap">
          <li className="nav-item mb-category">
            <NavLink to="/" className="nav-link" onClick={() => closeDrawer()}>All Category</NavLink>
          </li>
          <li className="nav-item">
            <NavLink to="/service-ticket" className="nav-link" onClick={() => closeDrawer()}>Service Ticket</NavLink>
          </li>
          <li className="nav-item">
            <NavLink to="/home-service" className="nav-link" onClick={() => closeDrawer()}>Home Service</NavLink>
          </li>
          <li className="nav-item">
            <NavLink to="/express-service" className="nav-link" onClick={() => closeDrawer()}>Express Service</NavLink>
          </li>
          <li className="nav-item">
            <NavLink to="/aboutus" className="nav-link" onClick={() => closeDrawer()}>About Us</NavLink>
          </li>
          <li className="nav-item">
            <NavLink to="/contactus" className="nav-link" onClick={() => closeDrawer()}>Contact Us</NavLink>
          </li>
        </ul>
        <MenuDropdown className="language">
          <p className="selected-lang">
            <img src={require("../../assets/img/icons/england-flag.jpg").default} alt="language" />
            <span>English</span>
            <MdKeyboardArrowDown />
          </p>
          <div className="drp-wrap">
            <ul className="drp-ul lang-list">
              <li onClick={() => closeDrawer()}><img src={require("../../assets/img/icons/england-flag.jpg").default} alt="england" /><span>English</span></li>
              <li onClick={() => closeDrawer()}><img src={require("../../assets/img/icons/myanmar-flag.jpg").default} alt="myanmar" /><span>Myanmar</span></li>
            </ul>
          </div>
        </MenuDropdown>
      </Components.Container>
    </NavContainer>
  )
}