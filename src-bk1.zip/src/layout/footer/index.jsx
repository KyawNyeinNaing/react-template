import React from 'react'
import { NavLink } from 'react-router-dom'
import { FooterWrapper, Title, List, SocialDiv, ContactDiv } from './style/footerstyle'
import { BiMap } from 'react-icons/bi'
import { ImPhone } from 'react-icons/im'
import { IoIosMail } from 'react-icons/io'
import { FaInstagram, FaViber } from 'react-icons/fa'
import { GrFacebookOption } from 'react-icons/gr'
import Components from '../../components'

const Footer = () => {
  return (
    <>
      <FooterWrapper>
        <div className="top-footer">
          <div className="overlay"></div>
          <Components.Container className='footer-container'>
            <Components.Row>
              <Components.Col lg="3" className="footer-col">
                <div className="logo">
                  <img src={require("../../assets/img/icons/stead-fast-logo-white.png").default} alt="logo" />
                </div>
                <ContactDiv>
                  <BiMap />
                  <p>No 23, Yadana Street, 16/2 Ward, Thingangyun Township, Yangon, Myanmar.</p>
                </ContactDiv>
                <ContactDiv>
                  <ImPhone />
                  <ul className='contact'>
                    <li>
                      <a href="tel:0912345678">+95 9xxxxxxxx</a>
                    </li>
                    <li>
                      <a href="tel:0912345678">+95 9xxxxxxxx</a>
                    </li>
                    <li>
                      <a href="tel:0912345678">+95 9xxxxxxxx</a>
                    </li>
                  </ul>
                </ContactDiv>
                <ContactDiv>
                  <IoIosMail />
                  <ul className='contact'>
                    <li>
                      <a href="mailto:xxxxx@mail.com">xxxxx@mail.com</a>
                    </li>
                    <li>
                      <a href="mailto:xxxxx@mail.com">xxxxx@mail.com</a>
                    </li>
                    <li>
                      <a href="mailto:xxxxx@mail.com">xxxxx@mail.com</a>
                    </li>
                  </ul>
                </ContactDiv>
                
                <SocialDiv>
                  <a href="https://facebook.com" target="_blank" rel="noreferrer">
                    <GrFacebookOption />
                  </a>
                  <a href="https://instagram.com" target="_blank" rel="noreferrer">
                    <FaInstagram />
                  </a>
                  <a href="tel:0912345678" rel="noreferrer">
                    <FaViber />
                  </a>
                </SocialDiv>
              </Components.Col>
              <Components.Col lg="3" className="footer-col">
                <Title>
                  Column
                </Title>
                <List>
                  <li>
                    <NavLink to="/aboutus">Label</NavLink>
                  </li>
                  <li>
                    <NavLink to="/contactus">Label</NavLink>
                  </li>
                </List>
              </Components.Col>
            </Components.Row>
          </Components.Container>
        </div>
        <div className="copyright">
          <Components.Copyright data="Company Name" />
        </div>
      </FooterWrapper>
    </>
  )
}

export default Footer