import { lazy } from 'react'

const NotFound = lazy(() => import('./notfound'))

const Index = {
  NotFound
}

export default Index