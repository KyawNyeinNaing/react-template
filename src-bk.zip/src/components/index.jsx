import { lazy } from 'react'

import {
  Main,
  Section,
  Container,
  Row,
  Col,
  View,
  Text,
  Input,
  Title,
  Desc,
  Button,
  AuthForm,
  Quantity,
  Image,
  InputGroup, 
  Label, 
  Span, 
  Error, 
  ErrorMessage, 
  StyledCheckBox,
  RTEContent,
  Copyright
} from './core'

// import {

// } from './constant'

export * from './core'
export * from './constant'
export * from './Loading'

// banner
const HomeBanner = lazy(() => import('./banner/HomeBanner'))

// card
const ProductCard = lazy(() => import('./card/ProductCard'))

// modal
const Modal = lazy(() => import('./modal/Modal'))

// product slider
const ProductSlider = lazy(() => import('./slider/productslider'))

// breadcrumb
const Breadcrumb = lazy(() => import('./breadcrumb'))

// sidebar
const ProductSidebar = lazy(() => import('./sidebar/productsidebar'))
const Sidebar = lazy(() => import('./sidebar/sidebar'))

// table
const TableCom = lazy(() => import('./table'))

// form
const TextInput = lazy(() => import('./form/Input'))
const Select = lazy(() => import('./form/Select'))
const TextArea = lazy(() => import('./form/Textarea'))
const CheckBox = lazy(() => import('./form/Checkbox'))
const DatePickerField = lazy(() => import('./form/Datepicker'))

// result
const SuccessMsg = lazy(() => import('./result/SuccessMsg'))

// Ads
const Advertisement = lazy(() => import('./ads'))

//service
const ServiceForm = lazy(() => import('./service/ServiceForm'))
const Confirmation = lazy(() => import('./service/Confirmation'))

const Components = {
  HomeBanner,
  Modal,
  ProductCard,
  ProductSlider,
  Breadcrumb,
  Sidebar,
  ProductSidebar,
  TableCom,
  TextInput,
  Select,
  TextArea,
  CheckBox,
  DatePickerField,
  SuccessMsg,
  Advertisement,
  ServiceForm,
  Confirmation,

  // grid
  Main, 
  Section, 
  Container, 
  Row, 
  Col,
  View,
  Text,
  Title,
  Desc,
  Button,
  AuthForm,
  Quantity,
  Image,
  InputGroup,
  Input,
  Label, 
  Span, 
  Error, 
  ErrorMessage, 
  StyledCheckBox,
  RTEContent,
  Copyright
}

export default Components
