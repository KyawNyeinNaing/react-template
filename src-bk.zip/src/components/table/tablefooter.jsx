import React from 'react'

const TableFooter = () => {
  return (
    <div>
      This is Table Footer
    </div>
  )
}

export default TableFooter
