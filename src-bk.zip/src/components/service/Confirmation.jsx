import React from 'react'
import Components from '../../components'
import { Service } from './style/ServiceStyle'

const payImage = [
  { name: 'kbz bank', image: require('../../assets/icons/kbz.png').default },
  { name: 'aya bank', image: require('../../assets/icons/aya.png').default },
  { name: 'kbz pay', image: require('../../assets/icons/kpay.png').default },
  { name: 'aya bank', image: require('../../assets/icons/aya-pay.png').default },
  { name: 'cb bank', image: require('../../assets/icons/cb.png').default },
  { name: 'aya bank', image: require('../../assets/icons/aya-pay.png').default },
  { name: 'cb bank', image: require('../../assets/icons/cb.png').default }
]

const Confirmation = () => {
  return (
    <Components.Section>
      <Components.Container>
        <Components.Row>
          <Components.Col offset_md="2">
            <Service>
              <Components.View as="div" className="confirm-content">
                <Components.Text as="h5">Confirmation For Requesting HomeService</Components.Text>
                <div className="d-flex">
                  <label>Customer Name</label>
                  <span>Customer Name</span>
                </div>
                <div className="d-flex">
                  <label>Email</label>
                  <span>xxxxxxx@xxxx.com</span>
                </div>
                <div className="d-flex">
                  <label>Mobile Phone</label>
                  <span>+95 9 xxxxxxxxx</span>
                </div>
                <div className="d-flex">
                  <label>Address to Come</label>
                  <span>Address</span>
                </div>
                <div className="d-flex">
                  <label>Division</label>
                  <span>Yangon</span>
                </div>
                <div className="d-flex">
                  <label>Township</label>
                  <span>Hlaing Township</span>
                </div>
                <div className="d-flex">
                  <label>Service Type</label>
                  <span>Service Type Name</span>
                </div>
                <div className="d-flex">
                  <label>Appointment Date/Time</label>
                  <span>07/01/2021 10 : 00 AM</span>
                </div>
                <div className="d-flex">
                  <label>Subject</label>
                  <span>Lorem Ipsum is simply dummy text</span>
                </div>
                <div className="d-flex">
                  <label>Customer Message</label>
                  <span>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</span>
                </div>
                <Components.Text weight="lg" color="secondary">* For this service, customers need to transfer (20000 Ks) in advance.</Components.Text>
                <Components.View as="div" className="pay-with">
                  <Components.Text weight="lg">Payment Method: 2C2P</Components.Text>
                  <div as="div" className="d-flex center">
                    {payImage?.length > 0 &&
                      payImage?.map((x, i) => (
                        <div className="pay-img" key={i}>
                          <Components.Image src={x.image} alt={x.name} />
                        </div>
                      ))
                    }
                  </div>
                </Components.View>
                <div className="submit-wrap">
                  <Components.Button type='submit' className="btn btn-default upper">Request Service</Components.Button>
                </div>
              </Components.View>
            </Service>
          </Components.Col>
        </Components.Row>
      </Components.Container>
    </Components.Section>
  )
}

export default Confirmation
