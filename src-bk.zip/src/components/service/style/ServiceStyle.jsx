import styled from 'styled-components'
import { fontSize, fontWeight } from '../../../components'
import colors from '../../../components/constant/Color'
import media from '../../../components/constant/Media'

const Service = styled.div`
  .d-flex {
    display: flex;
    align-items: flex-start;
    justify-content: flex-start;
  }
  .service {
    padding: 30px;
    background: ${colors.white};
    > * {
      margin-bottom: 20px;
      &:last-child {
        margin-bottom: 0;
      }
    }
    h5 {
      font-size: ${fontSize.xl}px;
      font-weight: ${fontWeight.lg};
    }
    .submit-wrap {
      text-align: center;
      margin-top: 20px;
      > * {
        margin-bottom: 15px;
        &:last-child {
          margin-bottom: 0;
        }
      }
    }
  }
  
  //confirmation
  .confirm-content {
    padding: 15px;
    background: ${colors.white};
    @media screen and (min-width: ${media.md}px) {
      padding: 50px;
    }
    > * {
      margin-bottom: 10px;
      &:first-child {
        margin-bottom: 15px;
        @media screen and (min-width: ${media.md}px) {
          margin-bottom: 30px;
        }
      }
    }
    h5 {
      font-size: ${fontSize.lg}px;
      font-weight: ${fontWeight.lg};
      text-align: center;
      @media screen and (min-width: ${media.md}px) {
        font-size: ${fontSize.xl}px;
      }
    }
    label,
    span {
      position: relative;
      display: inline-block;
      &:not(span) {
        width: 150px;
        padding-right: 15px;
        @media screen and (min-width: ${media.md}px) {
          width: 250px;
        }
        &:after {
          content: ':';
          position: absolute;
          top: 0;
          right: 10px;
        }
      }
      &:not(label) {
        width: 195px;
        padding-left: 5px;
        @media screen and (min-width: ${media.md}px) {
          width: auto;
          padding-left: 20px;
        }
      }
    }
    .submit-wrap {
      text-align: center;
      margin-top: 40px;
      > * {
        margin-bottom: 15px;
        &:last-child {
          margin-bottom: 0;
        }
      }
    }

    .pay-with {
      border: 2px solid ${colors.secondary};
      padding: 15px;
      margin-bottom: 40px;
      width: 100%;
      @media screen and (min-width: ${media.md}px) {
        width: 70%;
      }
      > * {
        margin-bottom: 15px;
        &:last-child {
          margin-bottom: 0;
        }
      }
      .pay-img {
        width: 65px;
        height: 40px;
        border: 1px solid ${colors.whisper};
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 15px;
        &:last-child {
          margin-right: 0;
        }
        img {
          width: auto;
          height: 40px;
        }
      }
    }
  }
`

export { Service }