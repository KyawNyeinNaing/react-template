export const adsKey = {
  center_ads: 'center-ads',
  side_ads: 'side-ads',
  slider_ads: 'slider-ads'
}
