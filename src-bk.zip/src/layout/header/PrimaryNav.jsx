import React, { useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
import { Container } from '../../components/core'
import { Wrapper, MegaMenu, MenuDropdown } from './style/headerstyle'
import { BiMenu } from "react-icons/bi"
import { MdKeyboardArrowDown, MdKeyboardArrowRight } from 'react-icons/md'
import { closeDrawer } from '../../utils'

const category = [
  {
    id: 1,
    patch: "/productlist",
    category_name: "Automotive",
    img: require("../../assets/img/back-red.png").default,
    subcategory: [
      {
        patch: "/productlist",
        category_name: "Polishes & Wax"
      },
      {
        patch: "/productlist",
        category_name: "Polishes & Wax"
      },
      {
        patch: "/productlist",
        category_name: "Coating"
      },
      {
        patch: "/productlist",
        category_name: "Cleaner"
      },
      {
        patch: "/productlist",
        category_name: "Cleaner"
      },
    ]
  },
  {
    id: 2,
    patch: "/productlist",
    category_name: "Auto Care",
    img: require("../../assets/img/back-red.png").default,
    subcategory: [
      {
        patch: "/productlist",
        category_name: "Cleaner"
      },
      {
        patch: "/productlist",
        category_name: "Cleaner"
      },
      {
        patch: "/productlist",
        category_name: "Cleaner"
      },
      {
        patch: "/productlist",
        category_name: "Cleaner"
      },
      {
        patch: "/productlist",
        category_name: "Cleaner"
      },
    ]
  },
  {
    id: 3,
    patch: "/productlist",
    category_name: "Auto Electronics",
    img: require("../../assets/img/back-red.png").default,
    subcategory: [
      {
        patch: "/productlist",
        category_name: "Coating"
      },
      {
        patch: "/productlist",
        category_name: "Coating"
      },
      {
        patch: "/productlist",
        category_name: "Coating"
      },
      {
        patch: "/productlist",
        category_name: "Coating"
      },
      {
        patch: "/productlist",
        category_name: "Coating"
      },
    ]
  },
  {
    id: 4,
    patch: "/productlist",
    category_name: "Automotive",
    subcategory: []
  },
  {
    id: 5,
    patch: "/productlist",
    category_name: "Automotive",
    subcategory: [
      {
        patch: "/productlist",
        category_name: "Polishes & Wax"
      },
      {
        patch: "/productlist",
        category_name: "Polishes & Wax"
      },
      {
        patch: "/productlist",
        category_name: "Coating"
      },
      {
        patch: "/productlist",
        category_name: "Cleaner"
      },
      {
        patch: "/productlist",
        category_name: "Cleaner"
      },
    ]
  },
  {
    id: 6,
    patch: "/productlist",
    category_name: "Automotive",
    subcategory: [
      {
        patch: "/productlist",
        category_name: "Polishes & Wax"
      },
      {
        patch: "/productlist",
        category_name: "Polishes & Wax"
      },
      {
        patch: "/productlist",
        category_name: "Coating"
      },
      {
        patch: "/productlist",
        category_name: "Cleaner"
      },
      {
        patch: "/productlist",
        category_name: "Cleaner"
      },
    ]
  },
  {
    id: 7,
    patch: "/productlist",
    category_name: "Automotive",
    subcategory: [
      {
        patch: "/productlist",
        category_name: "Polishes & Wax"
      },
      {
        patch: "/productlist",
        category_name: "Polishes & Wax"
      },
      {
        patch: "/productlist",
        category_name: "Coating"
      },
      {
        patch: "/productlist",
        category_name: "Cleaner"
      },
      {
        patch: "/productlist",
        category_name: "Cleaner"
      },
    ]
  },
  {
    id: 8,
    patch: "/productlist",
    category_name: "Automotive",
    subcategory: [
      {
        patch: "/productlist",
        category_name: "Polishes & Wax"
      },
      {
        patch: "/productlist",
        category_name: "Polishes & Wax"
      },
      {
        patch: "/productlist",
        category_name: "Coating"
      },
      {
        patch: "/productlist",
        category_name: "Cleaner"
      },
      {
        patch: "/productlist",
        category_name: "Cleaner"
      },
    ]
  },
  {
    id: 9,
    patch: "/productlist",
    category_name: "Automotive",
    subcategory: [
      {
        patch: "/productlist",
        category_name: "Polishes & Wax"
      },
      {
        patch: "/productlist",
        category_name: "Polishes & Wax"
      },
      {
        patch: "/productlist",
        category_name: "Coating"
      },
      {
        patch: "/productlist",
        category_name: "Cleaner"
      },
      {
        patch: "/productlist",
        category_name: "Cleaner"
      },
    ]
  },
  {
    id: 10,
    patch: "/productlist",
    category_name: "Automotive",
    subcategory: [
      {
        patch: "/productlist",
        category_name: "Polishes & Wax"
      },
      {
        patch: "/productlist",
        category_name: "Polishes & Wax"
      },
      {
        patch: "/productlist",
        category_name: "Coating"
      },
      {
        patch: "/productlist",
        category_name: "Cleaner"
      },
      {
        patch: "/productlist",
        category_name: "Cleaner"
      },
    ]
  }
]

export default function PrimaryNav () {
  const [show, setShow] = useState(false)
  const [active, setActive] = useState(null)

  // drop down megamenu 
  const handleDropdown = () => {
    show ? setShow(false) : setShow(true)
    let getIndex = category.indexOf(category.find(x => x.subcategory.length > 0))
    setActive(getIndex)
  }

  // handle subcategory
  const handleCategory = (key) => {
    key !== active && setActive(key)
  }

  return (
    <Wrapper primary className="primaryNav">
      <Container className="nav-container">
        <ul className="nav-item-wrap">
          <li className="nav-item category">
            <button className="nav-link" onClick={() => handleDropdown()}>
              <span>
                <BiMenu />
                All Category
              </span>
              <MdKeyboardArrowDown />
            </button>
            <MegaMenu className={`megamenu ${show ? "show" : "hide"}`}>
              <div className="mega-wrap">
                <div className="mega-item">
                  <ul className="category">
                    {
                      category.map((data, key) =>
                        <li className={`category-list ${key !== active ? "" : "active"}`} key={key}>
                          {
                            data?.subcategory.length > 0 ?
                            <button className="btn-category" onClick={() => handleCategory(key)}>{data?.category_name}<MdKeyboardArrowRight /></button> :
                            <Link className="btn-category" to={data?.patch} onClick={() => setShow(false)}>{data?.category_name}</Link>
                          }
                          <div className="subcategory-wrap">
                            <ul className="subcategory">
                              { 
                                data?.subcategory.map((subdata, key) =>
                                  <li className="subcategory-list" key={key}>
                                    <Link to={subdata?.patch} className="item-link" onClick={() => setShow(false)}>{subdata?.category_name}</Link>
                                  </li>
                                )
                              }
                            </ul>
                            <div className="mega-img">
                              <img src={data?.img} alt="" />
                            </div>
                          </div>
                        </li>
                      )
                    }
                  </ul>
                </div>
              </div>    
            </MegaMenu>
          </li>
          <li className="nav-item mb-category">
            <NavLink to="/" className="nav-link" onClick={() => closeDrawer()}>All Category</NavLink>
          </li>
          <li className="nav-item">
            <NavLink to="/service-ticket" className="nav-link" onClick={() => closeDrawer()}>Service Ticket</NavLink>
          </li>
          <li className="nav-item">
            <NavLink to="/home-service" className="nav-link" onClick={() => closeDrawer()}>Home Service</NavLink>
          </li>
          <li className="nav-item">
            <NavLink to="/express-service" className="nav-link" onClick={() => closeDrawer()}>Express Service</NavLink>
          </li>
          <li className="nav-item">
            <NavLink to="/aboutus" className="nav-link" onClick={() => closeDrawer()}>About Us</NavLink>
          </li>
          <li className="nav-item">
            <NavLink to="/contactus" className="nav-link" onClick={() => closeDrawer()}>Contact Us</NavLink>
          </li>
        </ul>
        <MenuDropdown className="language">
          <p className="selected-lang">
            <img src={require("../../assets/img/icons/england-flag.jpg").default} alt="language" />
            <span>English</span>
            <MdKeyboardArrowDown />
          </p>
          <div className="drp-wrap">
            <ul className="drp-ul lang-list">
              <li onClick={() => closeDrawer()}><img src={require("../../assets/img/icons/england-flag.jpg").default} alt="england" /><span>English</span></li>
              <li onClick={() => closeDrawer()}><img src={require("../../assets/img/icons/myanmar-flag.jpg").default} alt="myanmar" /><span>Myanmar</span></li>
            </ul>
          </div>
        </MenuDropdown>
      </Container>
    </Wrapper>
  )
}