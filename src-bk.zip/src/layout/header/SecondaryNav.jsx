import React from 'react'
import { Link } from 'react-router-dom'
import Components from '../../components'
import Placeholder from '../../components/fakeimg'
import { Wrapper, MenuDropdown, MenuIcon } from './style/headerstyle'
import { BiSearch } from 'react-icons/bi'
import { FaRegUser } from "react-icons/fa"
import { AiOutlineShoppingCart } from "react-icons/ai"

export default function SecondaryNav() {
  const tmp = {
    width: 196,
    height: 76,
    // backgroundColor: colors.light,
    text: 'Logo (196 x 76)'
  }
  return (
    <Wrapper secondary>
      <Components.Container>
        <div className="secondaryNav">
          <Link to="/" className="logo-img">
            <Placeholder {...tmp} />
            {/* <img className="steadfast-logo" src={require('../../assets/img/icons/stead-fast-logo.png').default} alt="logo" /> */}
          </Link>

          <div className="nav-center">
            <Components.Input type="text" placeholder="Search product" className="search-box" />
            <div className="search-icon">
              <BiSearch />
            </div>
          </div>
          
          <div className="nav-right">
            <div className="nav-flex">
              <div className="user-wrap d-flex border-right">
                {
                  localStorage.getItem("signin") === "true" ?
                  <MenuDropdown className="d-flex">
                    <FaRegUser className='user-icon' />
                    <p className="user-info">
                      <span className="sub">Welcome</span>
                      <br/>
                      <span className="title">John Smith</span>
                    </p>
                    <div className="drp-wrap">
                      <ul className="drp-ul">
                        <li>
                          <Link to='/profile'>
                            My Profile
                          </Link>
                        </li>
                        <li>
                          <Link to='/orderhistory'>
                            My Order
                          </Link>
                        </li>
                        <li>
                          <Link to='/'>
                            My Service Tickets
                          </Link>
                        </li>
                        <li>
                          <Link to='/wishlist'>
                            My Wishlist
                          </Link>
                        </li>
                        <li>
                          <Link to="/">Logout</Link>
                        </li>
                      </ul>
                    </div>
                  </MenuDropdown>
                  :
                  <MenuDropdown className="d-flex">
                    <FaRegUser className='user-icon' />
                    <p className="user-info">
                      <span className="sub">Login Here</span>
                      <br/>
                      <span className="title">My Account</span>
                    </p>
                    <div className="drp-wrap">
                      <ul className="drp-ul">
                        <li>
                          <Link to='/signin'>
                            Login
                          </Link>
                        </li>
                        <li>
                          <Link to='/signup'>
                            Sign Up
                          </Link>
                        </li>
                      </ul>
                    </div>
                  </MenuDropdown>
                }
              </div>

              <div className="user-wrap d-flex border-right">
                <MenuDropdown className="d-flex">
                  <AiOutlineShoppingCart />
                  <span className="item">6</span>
                  <p className="user-info">
                    <span className="sub">Shopping Cart</span>
                    <br/>
                    <span className="title">6 Items</span>
                  </p>
                </MenuDropdown>
              </div>

              <MenuIcon className="menu-btn">
                <div className="menu-icon"></div>
              </MenuIcon>
            </div>
          </div>
        </div>
      </Components.Container>
    </Wrapper>
  )
}