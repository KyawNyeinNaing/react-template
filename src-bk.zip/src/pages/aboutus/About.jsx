import React from 'react'
import Components from '../../components'
import { About } from './style/aboutstyle'

const breadcrumb_data = [
  {
    name: 'About Us'
  }
]

const AboutUs = () => {
  return (
    <>
      <Components.Breadcrumb data={breadcrumb_data} />
      <Components.Section>
        <Components.Container>
          <Components.Row>
            <Components.Col sm="5">
              <Components.Image src={require("../../assets/img/servicce-ticket-2.png").default} />
            </Components.Col>
            <Components.Col sm="7">
              <Components.About>
                <Components.Text as="h3">About Us</Components.Text>
              </Components.About>
            </Components.Col>
          </Components.Row>
        </Components.Container>
      </Components.Section>
    </>
  )
}

export default AboutUs
