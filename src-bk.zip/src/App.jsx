import React from 'react'
import AppLayout from './layout'
import 'slick-carousel/slick/slick.css'
import 'slick-carousel/slick/slick-theme.css'

const App = () => {
  return (
    <AppLayout />
  )
}

export default App