import Home from '../pages/home'
import About from '../pages/aboutus'
import Contact from '../pages/contactus'
import Terms from '../pages/terms'
import Result from '../pages/result'

const Routes = [
  {
    path: "/",
    component: Home.home
  },
  {
    path: '/aboutus',
    component: About.aboutus
  },
  {
    path: '/contactus',
    component: Contact.contactus
  },
  {
    path: '/termsandconditions',
    component: Terms.term
  },
  {
    path: '/privacypolicy',
    component: Terms.privacy
  },
  {
    path: '*',
    component: Result.notfound
  }
]

export default Routes